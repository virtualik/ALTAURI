﻿package Src.Commands {
    import flash.events.Event;
    import flash.events.EventDispatcher;
    import flash.utils.Timer;
    import flash.events.TimerEvent;
    import Src.Commands.CommandErrorEvent;
    import Src.Commands.ICommand;

    public class ParallelCommand extends EventDispatcher implements ICommand {
        private var _commands:Array;
        private var _completeCommandCount:int;
        private var _delay:Number;

        public function ParallelCommand(delay:Number, ...commands) {
            _delay = delay;

            if (commands.length == 1 && commands[0] is Array) {
                _commands = commands[0];
            } else {
                _commands = commands;
            }

            _completeCommandCount = 0;
        }

        public function execute():void {
            _completeCommandCount = 0;

            if (_commands.length == 0) {
                dispatchEvent(new Event(Event.COMPLETE));
                return;
            }

            if (_delay > 0) {
                var timer:Timer = new Timer(int(1000 * _delay), 1);
                timer.addEventListener(TimerEvent.TIMER_COMPLETE, onDelayComplete);
                timer.start();
            } else {
                startAllCommands();
            }
        }

        private function onDelayComplete(e:TimerEvent):void {
            var timer:Timer = e.target as Timer;
            timer.removeEventListener(TimerEvent.TIMER_COMPLETE, onDelayComplete);
            startAllCommands();
        }

        private function startAllCommands():void {
            for each (var command:ICommand in _commands) {
                if (command is EventDispatcher) {
                    (command as EventDispatcher).addEventListener(Event.COMPLETE, onSubcommandComplete);
                    (command as EventDispatcher).addEventListener(CommandErrorEvent.ERROR, onSubcommandError);
                }
                command.execute();
            }
        }

        private function onSubcommandComplete(e:Event):void {
            var command:ICommand = e.target as ICommand;

            if (command is EventDispatcher) {
                (command as EventDispatcher).removeEventListener(Event.COMPLETE, onSubcommandComplete);
                (command as EventDispatcher).removeEventListener(CommandErrorEvent.ERROR, onSubcommandError);
            }

            _completeCommandCount++;

            if (_completeCommandCount == _commands.length) {
                dispatchEvent(new Event(Event.COMPLETE));
            }
        }

        private function onSubcommandError(event:CommandErrorEvent):void {
            var failedCommand:ICommand = event.target as ICommand;

            if (failedCommand is EventDispatcher) {
                (failedCommand as EventDispatcher).removeEventListener(Event.COMPLETE, onSubcommandComplete);
                (failedCommand as EventDispatcher).removeEventListener(CommandErrorEvent.ERROR, onSubcommandError);
            }

            cleanupAllListeners();

            dispatchEvent(new CommandErrorEvent(CommandErrorEvent.ERROR,
                "Error in parallel command: " + event.errorMessage));
        }

        private function cleanupAllListeners():void {
            for each (var command:ICommand in _commands) {
                if (command is EventDispatcher) {
                    (command as EventDispatcher).removeEventListener(Event.COMPLETE, onSubcommandComplete);
                    (command as EventDispatcher).removeEventListener(CommandErrorEvent.ERROR, onSubcommandError);
                }
            }
        }
    }
}
